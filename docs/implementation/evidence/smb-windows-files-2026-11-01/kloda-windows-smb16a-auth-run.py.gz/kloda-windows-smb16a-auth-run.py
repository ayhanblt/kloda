from pathlib import Path
import os,stat,subprocess,tempfile,json,hashlib
repo=Path('/Users/ayhanblt/Desktop/projects/kloda');credential=Path('/private/tmp/kloda-windows16a.DpaotM/password')
for p,mode in [(credential.parent,0o700),(credential,0o600)]:
 m=p.lstat();assert not p.is_symlink() and m.st_uid==os.getuid() and stat.S_IMODE(m.st_mode)==mode
assert credential.is_file() and 0<credential.stat().st_size<=4096
root=Path(tempfile.mkdtemp(prefix='kloda-windows-smb16a-auth-'));print('Evidence: '+str(root),flush=True)
source=repo/'packages/storage-native/tests/windows_auth_owned.rs';digest=hashlib.sha256(source.read_bytes()).hexdigest();compiler=Path(subprocess.check_output(['rustup','which','--toolchain','1.99.0','rustc'],text=True).strip())
env={**os.environ,'PATH':str(compiler.parent)+os.pathsep+os.environ['PATH'],'RUSTC':str(compiler),'RUSTDOC':str(compiler.with_name('rustdoc'))}
command=[str(compiler.with_name('cargo')),'test','--locked','--offline','--manifest-path',str(repo/'packages/storage-native/Cargo.toml'),'--target-dir','/tmp/kloda-smb16-adopt-target','--test','windows_auth_owned']
with (root/'build.log').open('w') as log:subprocess.run([*command,'--no-run'],check=True,env=env,stdout=log,stderr=subprocess.STDOUT)
assert hashlib.sha256(source.read_bytes()).hexdigest()==digest
with (root/'auth.log').open('w') as log:
 p=subprocess.run([*command,'--','--ignored','--nocapture'],env={**env,'KLODA_SMB16_WINDOWS_AUTH':'owned-auth-only','KLODA_SMB16_WINDOWS_PASSWORD_FILE':str(credential)},stdout=log,stderr=subprocess.STDOUT,timeout=35)
(root/'result.json').write_text(json.dumps({'sourceSha256':digest,'exitCode':p.returncode,'scope':'Host wire auth/tree only; zero file operations; no iOS route/source authority proof'},indent=2)+'\n')
print('PASS auth-only' if p.returncode==0 else 'FAILED auth-only; see sanitized stage log',flush=True)
raise SystemExit(p.returncode)
