from pathlib import Path
import subprocess,plistlib,tempfile,uuid,json,hashlib
repo=Path('/Users/ayhanblt/Desktop/projects/kloda');native=repo/'apps/mobile/modules/my-module/ios';root=Path(tempfile.mkdtemp(prefix='kloda-windows-smb16a-files-'));print('Evidence: '+str(root),flush=True)
nonce=str(uuid.uuid4());bundle='com.kloda.fixture.smb16.windows.r'+uuid.uuid4().hex;app=root/'SmbWindowsFiles.app';app.mkdir();source=repo/'packages/storage-native/apple/tests/IosSmbWindowsFilesApp.swift'
sources=sorted(p for p in native.glob('*.swift') if 'import ExpoModulesCore' not in p.read_text())+sorted((native/'NativePairing').glob('*.swift'))
libraries=[native/'NativePairing/KlodaPairingNative.xcframework/ios-arm64-simulator/libkloda_pairing_native.a',native/'NativeStorage/KlodaStorageNative.xcframework/ios-arm64-simulator/libkloda_storage_native.a'];bridge=native/'NativePairing/KlodaPairingNative.h'
rights=root/'Fixture.entitlements';der=root/'Fixture.der';rights.write_bytes(plistlib.dumps({'keychain-access-groups':[bundle]}));subprocess.run(['derq','query','--raw','-f','xml','-i',str(rights),'-o',str(der)],check=True,capture_output=True)
assert plistlib.loads(subprocess.check_output(['derq','query','-i',str(der),'--xml']))=={'keychain-access-groups':[bundle]}
linker=[]
for section,p in [('__entitlements',rights),('__ents_der',der)]:linker+=['-Xlinker','-sectcreate','-Xlinker','__TEXT','-Xlinker',section,'-Xlinker',str(p)]
hashes={str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [*sources,source,bridge,*libraries]}
(root/'ownership.json').write_text(json.dumps({'bundle':bundle,'nonce':nonce,'remoteRoot':'kloda16a-'+nonce,'simulator':'497AAA0F-967E-4781-9468-3F05CA2D3D5A','inputs':hashes,'scope':'One4097-byte Files source via actual picker, one remote publication, local restore/repeat/reopen. No Photos, no remote deletion, no OS delivery/product UI acceptance.'},indent=2)+'\n')
sdk=subprocess.check_output(['xcrun','--sdk','iphonesimulator','--show-sdk-path'],text=True).strip()
with (root/'build.log').open('w') as log:subprocess.run(['xcrun','--sdk','iphonesimulator','swiftc','-swift-version','5','-sdk',sdk,'-target','arm64-apple-ios16.4-simulator','-D','KLODA_SMB_NATIVE','-module-cache-path',str(root/'cache'),*map(str,sources),str(source),'-import-objc-header',str(bridge),*map(str,libraries),*linker,'-framework','UIKit','-framework','Security','-framework','Network','-framework','SystemConfiguration','-framework','BackgroundTasks','-lsqlite3','-o',str(app/'SmbWindowsFiles')],check=True,stdout=log,stderr=subprocess.STDOUT)
assert all(hashlib.sha256((repo/p).read_bytes()).hexdigest()==h for p,h in hashes.items())
(app/'Info.plist').write_bytes(plistlib.dumps({'CFBundleExecutable':'SmbWindowsFiles','CFBundleIdentifier':bundle,'CFBundleDisplayName':'Owned SMB Windows16a','CFBundleName':'Owned SMB Windows16a','CFBundlePackageType':'APPL','CFBundleVersion':'1','CFBundleShortVersionString':'1','MinimumOSVersion':'16.4','UIDeviceFamily':[1],'UILaunchScreen':{},'UIFileSharingEnabled':True,'LSSupportsOpeningDocumentsInPlace':True,'FixtureNonce':nonce,'NSLocalNetworkUsageDescription':'Only the explicitly owned Windows SMB test share192.168.1.54.'}))
subprocess.run(['codesign','--force','--sign','-','--identifier',bundle,str(app)],check=True,capture_output=True)
print('PASS build/sign; NOT_RUN picker/Files/LAN publication',flush=True)
