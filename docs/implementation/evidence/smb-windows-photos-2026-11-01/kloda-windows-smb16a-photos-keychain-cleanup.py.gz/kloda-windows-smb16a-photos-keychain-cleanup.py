from pathlib import Path
import json,subprocess
r=Path('/var/folders/cm/fsyld6dn5xl1p74jcds8tc640000gn/T/kloda-windows-smb16a-photos-6sh541kb');o=json.loads((r/'ownership.json').read_text());c=Path((r/'container-path.txt').read_text());assert o['bundle'].startswith('com.kloda.fixture.smb16.windowsphotos.') and o['remoteRoot']=='kloda16a-photos-'+o['nonce'];s=o['simulator'];assert s=='497AAA0F-967E-4781-9468-3F05CA2D3D5A'
source=r/'cleanup.m';source.write_text('''#import <Foundation/Foundation.h>
#import <Security/Security.h>
int main(void) { @autoreleasepool {
 NSDictionary *query = @{(__bridge id)kSecClass:(__bridge id)kSecClassGenericPassword,(__bridge id)kSecAttrService:@"'''+o['bundle']+'''.smb.native.v1",(__bridge id)kSecAttrAccount:@"profile",(__bridge id)kSecAttrAccessGroup:@"'''+o['bundle']+'''"};
 NSMutableDictionary *read = [query mutableCopy]; read[(__bridge id)kSecReturnData]=@YES; CFTypeRef data=NULL;
 OSStatus before=SecItemCopyMatching((__bridge CFDictionaryRef)read,&data); if(before!=errSecSuccess || !data) return 2;
 NSData *bytes=CFBridgingRelease(data); NSDictionary *profile=[NSJSONSerialization JSONObjectWithData:bytes options:0 error:NULL]; NSDictionary *target=profile[@"target"];
 if(![target[@"root"] isEqual:@"'''+o['remoteRoot']+'''"] || ![target[@"address"] isEqual:@"192.168.1.54"] || ![target[@"share"] isEqual:@"KlodaTest16a"]) return 3;
 OSStatus removed=SecItemDelete((__bridge CFDictionaryRef)query); if(removed!=errSecSuccess) return 4;
 OSStatus after=SecItemCopyMatching((__bridge CFDictionaryRef)read,NULL); if(after!=errSecItemNotFound) return 5;
 puts("PASS exact fresh fixture profile removed; post-delete lookup=errSecItemNotFound; no other service/group touched"); return 0;
} }
''')
sdk=subprocess.check_output(['xcrun','--sdk','iphonesimulator','--show-sdk-path'],text=True).strip();binary=r/'cleanup';command=['xcrun','--sdk','iphonesimulator','clang','-target','arm64-apple-ios16.4-simulator','-isysroot',sdk,'-fobjc-arc','-fblocks','-Wall','-Wextra','-Werror',str(source),'-framework','Foundation','-framework','Security','-o',str(binary)]
for section,path in [('__entitlements',r/'Fixture.entitlements'),('__ents_der',r/'Fixture.der')]:command+=['-Xlinker','-sectcreate','-Xlinker','__TEXT','-Xlinker',section,'-Xlinker',str(path)]
subprocess.run(command,check=True,capture_output=True);subprocess.run(['codesign','--force','--sign','-',str(binary)],check=True,capture_output=True)
subprocess.run(['xcrun','simctl','terminate',s,o['bundle']],check=True,capture_output=True)
p=subprocess.run(['xcrun','simctl','spawn',s,str(binary)],check=True,capture_output=True,text=True,timeout=20);(r/'cleanup.log').write_text(p.stdout+p.stderr);print(p.stdout,flush=True)
assert not (c/'Library/Caches/fixture-password').exists()
subprocess.run(['xcrun','simctl','privacy',s,'reset','photos',o['bundle']],check=True,capture_output=True)
if o['bootedHere']:subprocess.run(['xcrun','simctl','shutdown',s],check=True,capture_output=True)
(r/'cleanup.json').write_text(json.dumps({'testProfileKeychainDeleted':True,'appTerminated':True,'privateAppPasswordInputRemoved':True,'simulatorShutdown':bool(o['bootedHere']),'remoteFixtureRetained':True,'sourceCredentialRetainedMode600ForNextAuthorizedSmbTest':True},indent=2)+'\n');print('Owned app/Simulator cleanup complete')
