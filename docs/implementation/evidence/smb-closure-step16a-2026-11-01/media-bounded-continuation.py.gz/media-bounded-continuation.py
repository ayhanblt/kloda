from pathlib import Path
import json,subprocess,sqlite3,time,hashlib,shutil
log=Path('/tmp/kloda-smb-import16a-approved-media2.log');root=Path(next(x for x in log.read_text().splitlines() if x.startswith('Evidence: ')).removeprefix('Evidence: '));o=json.loads((root/'ownership.json').read_text());repo=Path('/Users/ayhanblt/Desktop/projects/kloda');sim=o['simulator'];bundle=o['bundle'];assert o['photosEnabled'] and sim=='497AAA0F-967E-4781-9468-3F05CA2D3D5A' and bundle.startswith('com.kloda.fixture.smb16.import.r')
assert all(hashlib.sha256((repo/name).read_bytes()).hexdigest()==sha for name,sha in o['inputs'].items())
subprocess.run(['xcrun','simctl','terminate',sim,bundle],capture_output=True)
container=Path(subprocess.check_output(['xcrun','simctl','get_app_container',sim,bundle,'data'],text=True).strip());doc=container/'Documents'
con=sqlite3.connect('file:'+str(doc/'owned-import.sqlite')+'?mode=ro',uri=True);assert con.execute('SELECT COUNT(*) FROM smb_photo_import').fetchone()[0]==0 and con.execute('SELECT COUNT(*) FROM smb_photo_album').fetchone()[0]==0 and con.execute('SELECT COUNT(*) FROM smb_upload').fetchone()[0]==0;con.close()
# All prior invocations stopped before the importer: reset only these two owned private inputs, never Photos.
for name in ['manifest.json','owned.snapshot']:
 src=doc/name;assert src.is_file();shutil.copyfile(src,root/('before-permission-'+name));src.unlink()
print('PASS pre-create resume:0 import/album/upload rows; no additional importer calls consumed',flush=True)
try:
 for mode in ['seed','reopen','cleanup']:
  result=doc/(mode+'-result.json')
  if result.exists():shutil.copyfile(result,root/(mode+'-before-permission-result.json'));result.unlink()
  subprocess.run(['xcrun','simctl','launch',sim,bundle,mode],check=True,capture_output=True)
  end=time.monotonic()+60
  while not result.exists() and time.monotonic()<end:time.sleep(.2)
  outcome=json.loads(result.read_text());(root/(mode+'-approved-result.json')).write_text(json.dumps(outcome,sort_keys=True)+'\n');assert outcome=={'mode':mode,'sourceHash':o['sourceHash'],'status':'PASS'},outcome
  print('PASS '+mode,flush=True);subprocess.run(['xcrun','simctl','terminate',sim,bundle],check=True,capture_output=True)
 con=sqlite3.connect('file:'+str(doc/'owned-import.sqlite')+'?mode=ro',uri=True)
 summary={'importStates':list(con.execute('SELECT state,target,error_code FROM smb_photo_import')),'albumStates':list(con.execute('SELECT state,target FROM smb_photo_album')),'uploadRows':con.execute('SELECT COUNT(*) FROM smb_upload').fetchone()[0],'ownedIds':json.loads((doc/'owned-ids.json').read_text()),'manifest':json.loads((doc/'manifest.json').read_text()),'sourceHash':o['sourceHash']};con.close();assert summary['uploadRows']==0
 (root/'approved-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print('PASS all4 bounded importer calls + separate-process reopen + exact owned cleanup; no upload receipt fabricated',flush=True)
finally:
 subprocess.run(['xcrun','simctl','terminate',sim,bundle],capture_output=True)
 try:subprocess.run(['xcrun','simctl','privacy',sim,'reset','photos',bundle],check=True,capture_output=True)
 finally:subprocess.run(['xcrun','simctl','shutdown',sim],check=True,capture_output=True)
