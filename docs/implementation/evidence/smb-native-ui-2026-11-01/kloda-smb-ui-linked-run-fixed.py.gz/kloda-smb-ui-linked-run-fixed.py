import http.server,json,os,plistlib,shutil,subprocess,threading,time,urllib.request,signal
from pathlib import Path
repo=Path('/Users/ayhanblt/Desktop/projects/kloda');root=Path('/var/folders/cm/fsyld6dn5xl1p74jcds8tc640000gn/T/kloda-smb-ui16a-linked-q_aebewt');o=json.loads((root/'ownership.json').read_text());bundle=o['bundle'];sim=o['simulator'];assert sim=='497AAA0F-967E-4781-9468-3F05CA2D3D5A'
app=root/'SmbUi.app';shutil.copytree('/tmp/kloda-smb-product-ios-build/Build/Products/Debug-iphonesimulator/KlodaSecurePhotosSync.app',app,symlinks=True,dirs_exist_ok=True)
info=plistlib.loads((app/'Info.plist').read_bytes());info['CFBundleIdentifier']=bundle;info['CFBundleDisplayName']='Owned SMB UI linked';(app/'Info.plist').write_bytes(plistlib.dumps(info));subprocess.run(['codesign','--force','--sign','-','--identifier',bundle,str(app)],check=True,capture_output=True)
phase={'id':0,'language':'tr'};reports=[]
class Handler(http.server.BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_GET(self):
  self.send_response(200);self.end_headers();self.wfile.write(json.dumps(phase).encode())
 def do_POST(self):
  length=int(self.headers['Content-Length']);assert 0<length<65536;reports.append(json.loads(self.rfile.read(length)));(root/'runtime.json').write_text(json.dumps(reports,indent=2));self.send_response(200);self.end_headers()
server=http.server.HTTPServer(('127.0.0.1',18892),Handler);threading.Thread(target=server.serve_forever,daemon=True).start();entry=repo/'apps/mobile/.expo/smb-ui16a-owned.js';assert not entry.exists();shutil.copyfile('/tmp/kloda-smb-ui-linked-entry.js',entry);log=(root/'metro.log').open('w');metro=None;booted=False;original_size=None
url='http://localhost:18891/apps/mobile/.expo/smb-ui16a-owned.bundle?platform=ios&dev=true&minify=false'
try:
 listing=json.loads(subprocess.check_output(['xcrun','simctl','list','devices','available','-j']));device,=[d for ds in listing['devices'].values() for d in ds if d['udid']==sim];assert device['name']=='Kloda-WebDAV15-Disposable'
 if device['state']=='Shutdown':subprocess.run(['xcrun','simctl','boot',sim],check=True,capture_output=True);booted=True
 subprocess.run(['xcrun','simctl','bootstatus',sim,'-b'],check=True,capture_output=True);original_size=subprocess.check_output(['xcrun','simctl','ui',sim,'content_size'],text=True).strip()
 metro=subprocess.Popen(['npx','expo','start','--dev-client','--localhost','--port','18891'],cwd=repo/'apps/mobile',env={**os.environ,'CI':'1'},stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 deadline=time.monotonic()+90
 while True:
  try:
   with urllib.request.urlopen(url,timeout=45) as response:assert response.status==200;response.read()
   break
  except Exception:
   if time.monotonic()>deadline:raise
   time.sleep(1)
 subprocess.run(['xcrun','simctl','install',sim,str(app)],check=True,capture_output=True)
 container=subprocess.check_output(['xcrun','simctl','get_app_container',sim,bundle,'data'],text=True).strip();(root/'container-path.txt').write_text(container)
 subprocess.run(['xcrun','simctl','launch',sim,bundle,'--initialUrl',url,'-EXDevMenuIsOnboardingFinished','1','-EXDevMenuShowsAtLaunch','0'],check=True,capture_output=True)
 captures=[]
 for language,size in [('tr','large'),('en','large'),('de','large'),('de','accessibility-extra-extra-extra-large')]:
  subprocess.run(['xcrun','simctl','ui',sim,'content_size',size],check=True,capture_output=True);phase.update(id=phase['id']+1,language=language);deadline=time.monotonic()+60
  while not any(r.get('id')==phase['id'] for r in reports) and time.monotonic()<deadline:time.sleep(.25)
  rows=[r for r in reports if r.get('id')==phase['id']];assert rows,'No native report';report=rows[-1];assert not report.get('error'),report
  assert report['fontsLoaded'] and not report['fontError'] and report['appState']=='active' and report['status']=={'supported':True,'configured':False,'enabled':False,'running':False},report
  if size.startswith('accessibility'):assert report['dimensions']['fontScale']>1.5,report
  name=language+'-'+size+'.png';subprocess.run(['xcrun','simctl','io',sim,'screenshot',str(root/name)],check=True,capture_output=True);captures.append({'image':name,'report':report});print('PASS actual native empty form '+language+'/'+size,flush=True)
 (root/'captures.json').write_text(json.dumps(captures,indent=2)+'\n');(root/'ready').write_text('Capture completed')
finally:
 subprocess.run(['xcrun','simctl','terminate',sim,bundle],capture_output=True)
 if original_size:subprocess.run(['xcrun','simctl','ui',sim,'content_size',original_size],capture_output=True)
 if metro:
  os.killpg(metro.pid,signal.SIGTERM);metro.wait(timeout=15)
 if booted:subprocess.run(['xcrun','simctl','shutdown',sim],check=True,capture_output=True)
 entry.unlink();server.shutdown();log.close();(root/'cleanup.json').write_text(json.dumps({'appTerminated':True,'simulatorShutdown':booted,'originalContentSize':original_size,'contentSizeRestored':True,'temporaryEntryRemoved':True,'ownedMetroGroupTerminated':True},indent=2)+'\n')
