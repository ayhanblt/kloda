import React from 'react';
import { registerRootComponent } from 'expo';
import { View, AppState, useWindowDimensions } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { useFonts } from 'expo-font';
import '../global.css';
import { i18n } from '../src/shared/i18n';
import { ThemeProvider } from '../src/shared/theme/theme-provider';
import { MobileShell } from '../src/widgets/mobile-shell/ui';
import { SmbPage } from '../src/pages/connections/ui/smb-page';
import { smb } from '../src/shared/api/smb';
import interRegular from '../../../assets/fonts/inter/Inter-Regular.ttf';
import interMedium from '../../../assets/fonts/inter/Inter-Medium.ttf';
import interSemiBold from '../../../assets/fonts/inter/Inter-SemiBold.ttf';
import interBold from '../../../assets/fonts/inter/Inter-Bold.ttf';
// Owned empty-form capture: real native status, no configure/action/media/source calls.
function Checks() {
  const [phase, setPhase] = React.useState(null);
  const dimensions = useWindowDimensions();
  const [fontsLoaded, fontError] = useFonts({ KlodaInterRegular:interRegular, KlodaInterMedium:interMedium, KlodaInterSemiBold:interSemiBold, KlodaInterBold:interBold });
  React.useEffect(() => {
    let alive = true, current = -1;
    const poll = async () => {
      try {
        const next = await (await fetch('http://127.0.0.1:18892/phase')).json();
        if (alive && next.id !== current) { current = next.id; await i18n.changeLanguage(next.language); setPhase(next); }
      } catch {}
    };
    void poll(); const timer = setInterval(() => void poll(), 500);
    return () => { alive = false; clearInterval(timer); };
  }, []);
  React.useEffect(() => {
    if (!phase || !fontsLoaded) return;
    const timer = setTimeout(async () => {
      try {
        const status = await smb.status();
        await fetch('http://127.0.0.1:18892/report', { method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ ...phase,fontsLoaded,fontError:!!fontError,dimensions,status,appState:AppState.currentState }) });
      } catch (error) {
        await fetch('http://127.0.0.1:18892/report', { method:'POST',body:JSON.stringify({ ...phase,error:String(error) }) });
      }
    }, 2800);
    return () => clearTimeout(timer);
  }, [phase,fontsLoaded,fontError,dimensions]);
  if (!phase || !fontsLoaded) return <View />;
  return <SafeAreaProvider><ThemeProvider><MobileShell page="provider" navigate={() => undefined}><SmbPage key={phase.id} onBack={() => undefined} /></MobileShell></ThemeProvider></SafeAreaProvider>;
}
registerRootComponent(Checks);
