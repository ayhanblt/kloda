import http.server,json,os,plistlib,shutil,subprocess,tempfile,threading,time,uuid
from pathlib import Path
repo=Path('/Users/ayhanblt/Desktop/projects/kloda'); sim='497AAA0F-967E-4781-9468-3F05CA2D3D5A'
root=Path(tempfile.mkdtemp(prefix='kloda-smb-ui16a-')); print('Evidence: '+str(root),flush=True)
bundle='com.kloda.fixture.smb16.ui.r'+uuid.uuid4().hex
app=root/'SmbUi.app'; source=Path('/tmp/kloda-smb-product-ios-build/Build/Products/Debug-iphonesimulator/KlodaSecurePhotosSync.app')
shutil.copytree(source,app,symlinks=True)
info=plistlib.loads((app/'Info.plist').read_bytes()); info['CFBundleIdentifier']=bundle; info['CFBundleDisplayName']='Owned SMB UI'; (app/'Info.plist').write_bytes(plistlib.dumps(info))
subprocess.run(['codesign','--force','--sign','-','--identifier',bundle,str(app)],check=True,capture_output=True)
phase={'id':1,'language':'tr'}; reports=[]
class Handler(http.server.BaseHTTPRequestHandler):
 def log_message(self,*args): pass
 def do_GET(self):
  self.send_response(200);self.end_headers();self.wfile.write(json.dumps(phase).encode())
 def do_POST(self):
  value=json.loads(self.rfile.read(int(self.headers['Content-Length'])));reports.append(value);(root/'runtime.json').write_text(json.dumps(reports,indent=2));self.send_response(200);self.end_headers()
server=http.server.HTTPServer(('127.0.0.1',18892),Handler);threading.Thread(target=server.serve_forever,daemon=True).start()
entry=repo/'apps/mobile/.expo/smb-ui16a-owned.js'; assert not entry.exists();shutil.copyfile('/tmp/kloda-smb-ui-entry.js',entry)
(root/'ownership.json').write_text(json.dumps({'bundle':bundle,'simulator':sim,'source':str(source),'actions':['status only'],'ports':[18891,18892]},indent=2))
log=(root/'metro.log').open('w');metro=None; booted=False
try:
 listing=json.loads(subprocess.check_output(['xcrun','simctl','list','devices','available','-j']));device,=[d for ds in listing['devices'].values() for d in ds if d['udid']==sim];assert device['name']=='Kloda-WebDAV15-Disposable'
 if device['state']=='Shutdown': subprocess.run(['xcrun','simctl','boot',sim],check=True,capture_output=True);booted=True
 subprocess.run(['xcrun','simctl','bootstatus',sim,'-b'],check=True,capture_output=True)
 metro=subprocess.Popen(['npx','expo','start','--dev-client','--localhost','--port','18891'],cwd=repo/'apps/mobile',env={**os.environ,'CI':'1'},stdout=log,stderr=subprocess.STDOUT)
 time.sleep(8)
 subprocess.run(['xcrun','simctl','install',sim,str(app)],check=True,capture_output=True)
 subprocess.run(['xcrun','simctl','launch',sim,bundle,'--initialUrl','http://localhost:18891/apps/mobile/.expo/smb-ui16a-owned.bundle?platform=ios&dev=true&minify=false','-EXDevMenuIsOnboardingFinished','1','-EXDevMenuShowsAtLaunch','0'],check=True,capture_output=True)
 deadline=time.monotonic()+150
 while not reports and time.monotonic()<deadline: time.sleep(1)
 assert reports, 'No native report; inspect metro.log and screenshot'
 report=reports[-1];assert not report.get('error'),report
 assert report['fontsLoaded'] and not report['fontError'] and report['status']=={'supported':True,'configured':False,'enabled':False,'running':False},report
 subprocess.run(['xcrun','simctl','io',sim,'screenshot',str(root/'tr-smb.png')],check=True,capture_output=True)
 print('PASS native empty SMB status/fonts/render; '+str(root),flush=True)
 # Keep foreground available briefly for a scoped AX diagnostic if requested by the caller.
 (root/'ready').write_text('ready');time.sleep(40)
finally:
 subprocess.run(['xcrun','simctl','io',sim,'screenshot',str(root/'final.png')],capture_output=True)
 subprocess.run(['xcrun','simctl','terminate',sim,bundle],capture_output=True)
 if metro: metro.terminate();metro.wait(timeout=15)
 if booted: subprocess.run(['xcrun','simctl','shutdown',sim],check=True,capture_output=True)
 entry.unlink();server.shutdown();log.close()
